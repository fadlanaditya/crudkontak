/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.crudkontak.Connection;

//import com.mysql.cj.xdevapi.Statement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import java.sql.DriverManager;
import java.beans.Statement;
import java.sql.SQLException;

/**
 *
 * @author Fadlan
 */
public class Connection {
    public static Connection connect;
    public static Statement st;
    public static ResultSet rs;
    
    public static Connection getConnection(){
        if(connect==null){
            try{
                System.out.println("Make Connection...");
                Class.forName("com.mysql.cj.jdbc.Driver");
                connect=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/buku_kontak",
                        "root",
                        "");
                st = connect.createStatement();
                JOptionPane.showMessageDialog(null,"Connection Allowed");
                System.out.println("Connection Succesfully");
            }catch(ClassNotFoundException | SQLException e){
                JOptionPane.showMessageDialog(null, "Tidak Terkoneksi");
                System.out.println("Connection Succesfully");
            }
        }
        return connect;   
    }    
        public static void main(String[] args) {
        Connection.getConnection();
    }
    private Statement createStatement() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}